﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimuladorGastos
{
    class Sim_Gastos
    {







        public void CalcularFatura(IConsumidor ic)
        {


        }


        public void CalcularFaturaTotal(IConsumidor ic)
        {


        }

        public void CalcularArea(IConsumidor ic)
        {


        }

        public void CalcularAreaTotal(IConsumidor ic)
        {


        }


    }
}
