﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimuladorGastos
{
    abstract class Comodo : IConsumidor
    {
        protected float area, consumo;
        protected List<Eletrodomésticos> list_ED;
        public List<Eletrodomésticos> list_Padrão_ED;


        public virtual float ConsumoEnergia()
        {


            return consumo;

        }


        public virtual void ListarEletrodomestico()
        {
            


        }


    }
}
