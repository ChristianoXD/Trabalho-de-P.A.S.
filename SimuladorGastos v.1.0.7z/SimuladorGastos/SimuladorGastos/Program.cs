﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimuladorGastos
{
    class Program
    {
        public static int opcao = 0;

        public static Program program = new Program();        

        //Objetos para navegação de metodos das subclasses
        public static Quarto quarto = new Quarto();
        public static Sala sala = new Sala();
        public static Banheiro banheiro = new Banheiro();
        public static Cozinha cozinha = new Cozinha();
        //Objetos para navegação de metodos das subclasses


        //Objetos para comparação nos metodos de dicas _p = padrão
        public static Quarto quarto_p = new Quarto();
        public static Sala sala_p = new Sala();
        public static Banheiro banheiro_p = new Banheiro();
        public static Cozinha cozinha_p = new Cozinha();
        //Objetos para comparação nos metodos de dicas _p = padrão


        static void Main(string[] args)
        {
            
            opcao = program.Menu();   
                     

            while (opcao != 5)
            {
                Switch_Menu(opcao);
            }
        }


        //<<<<<<<<<<<<<<<<<<  INICIO DOS METODOS DE NAVEGAÇÃO DA MAIN >>>>>>>>>>>>>>>>>>>>>>>


        public int Menu()  // MENU PRINCIPAL
        {

            /*BLOCO PARA LEITURA DO LOG DO USUARIO, A DISCUTIR ONDE SERA REGISTRADO            
            
            FileStream fs = new FileStream("");
            StreamReader sr = new StreamReader(fs);           
            
            */       


            Console.Clear();
            Console.WriteLine("========================================================================");
            Console.WriteLine("                  Bem Vindo ao Simulador de Gastos");
            Console.WriteLine("========================================================================");
            Console.WriteLine("Escolha uma das opções\n");
            Console.WriteLine("1 - Cadastrar Eletrodoméstico");
            Console.WriteLine("2 - Ver Lista de Eletrodomesticos Cadastrados");
            Console.WriteLine("3 - Ver Consumo Total de Eletrodomesticos");            
            opcao = int.Parse(Console.ReadLine());


            return opcao;
        }


        public static void Switch_Menu(int opcao) //SWITCH DE OPÇAO DO MENU PRINCIPAL
        {
            int op_switch = 0;


            
                switch (opcao)
                {
                    case 1:

                    Console.WriteLine("========================================================================");
                    Console.WriteLine("Cadastro de Eletromestico Escolhido \n");
                    Console.WriteLine("Escolha em qual comodo deseja cadastrar: \n");
                    Console.WriteLine("1 - Sala");
                    Console.WriteLine("2 - Cozinha");
                    Console.WriteLine("3 - Quarto");
                    Console.WriteLine("4 - Banheiro");
                    Console.WriteLine("5 - Voltar ao menu principal");
                    op_switch = int.Parse(Console.ReadLine());
 
                    Menu_Case1(op_switch); // METODO COM SWITCH PARA CADASTRAR ELETRODOMESTICO EM COMODOS ESPECIFICOS


                        break;

                    case 2:

                    Console.WriteLine("========================================================================");
                    Console.WriteLine("Listar de Eletromestico Cadastrados Escolhido \n");
                    Console.WriteLine("Escolha qual uma opção: \n");
                    Console.WriteLine("1 - Listar Sala");
                    Console.WriteLine("2 - Listar Cozinha");
                    Console.WriteLine("3 - Listar Quarto");
                    Console.WriteLine("4 - Listar Banheiro");
                    Console.WriteLine("5 - Listar Todos os Comodos");
                    Console.WriteLine("6 - Voltar ao menu principal");
                    op_switch = int.Parse(Console.ReadLine());

                    Menu_Case2(op_switch);

                    break;


                    case 3:
                        break;


                    case 4:
                        break;

            }
            }        


        public static void Menu_Case1(int opcao) //METODO PARA INSERIR ELETRODOMESTICOS EM COMODO
        {
            string nome;
            float khw;
            int qtdED;
            Eletrodomésticos eletro;

            switch (opcao)
            {
                case 1:

                    Console.WriteLine("========================================================================");
                    Console.WriteLine("Cadastro de Eletromestico na Sala Escolhido \n");
                    Console.WriteLine("Informe o nome do eletrodomestico:");
                    nome = Console.ReadLine();

                    Console.WriteLine("Informe o consumo(Kilowatts/hora) do eletrodomestico:");
                    khw = float.Parse(Console.ReadLine());

                    Console.WriteLine("Informe a quantidade de eletrodomestico no comodo:");
                    qtdED = int.Parse(Console.ReadLine());

                    eletro = new Eletrodomésticos(nome, khw, qtdED);



                    sala.InserirEletrodomestico(eletro);

                    Console.WriteLine("Cadastro Concluido com Sucesso");
                    Console.ReadKey();

                    program.Menu();

                    break;


                case 2:

                    Console.WriteLine("========================================================================");
                    Console.WriteLine("Cadastro de Eletromestico na Cozinha Escolhido \n");
                    Console.WriteLine("Informe o nome do eletrodomestico:");
                    nome = Console.ReadLine();

                    Console.WriteLine("Informe o consumo(Kilowatts/hora) do eletrodomestico:");
                    khw = float.Parse(Console.ReadLine());

                    Console.WriteLine("Informe a quantidade de eletrodomestico no comodo:");
                    qtdED = int.Parse(Console.ReadLine());

                    eletro = new Eletrodomésticos(nome, khw, qtdED);

                    cozinha.InserirEletrodomestico(eletro);

                    Console.WriteLine("Cadastro Concluido com Sucesso");
                    Console.ReadKey();

                    program.Menu();

                    break;


                case 3:

                    Console.WriteLine("========================================================================");
                    Console.WriteLine("Cadastro de Eletromestico na Quarto Escolhido \n");
                    Console.WriteLine("Informe o nome do eletrodomestico:");
                    nome = Console.ReadLine();

                    Console.WriteLine("Informe o consumo(Kilowatts/hora) do eletrodomestico:");
                    khw = float.Parse(Console.ReadLine());

                    Console.WriteLine("Informe a quantidade de eletrodomestico no comodo:");
                    qtdED = int.Parse(Console.ReadLine());

                    eletro = new Eletrodomésticos(nome, khw, qtdED);

                    quarto.InserirEletrodomestico(eletro);

                    Console.WriteLine("Cadastro Concluido com Sucesso");
                    Console.ReadKey();

                    program.Menu();
                    break;


                case 4:

                    Console.WriteLine("========================================================================");
                    Console.WriteLine("Cadastro de Eletromestico na Cozinha Escolhido \n");
                    Console.WriteLine("Informe o nome do eletrodomestico:");
                    nome = Console.ReadLine();

                    Console.WriteLine("Informe o consumo(Kilowatts/hora) do eletrodomestico:");
                    khw = float.Parse(Console.ReadLine());

                    Console.WriteLine("Informe a quantidade de eletrodomestico no comodo:");
                    qtdED = int.Parse(Console.ReadLine());

                    eletro = new Eletrodomésticos(nome, khw, qtdED);

                    banheiro.InserirEletrodomestico(eletro);

                    Console.WriteLine("Cadastro Concluido com Sucesso");
                    Console.ReadKey();

                    program.Menu();
                    break;

                case 5:

                    program.Menu();
                                        
                    break;

            }
        }


        public static void Menu_Case2(int opcao) // METODO PARA IMPRESSAO DA LISTA DE ELETRODOMESTICO
        {

            switch (opcao)
            {

                case 1:
                    sala.ListarEletrodomestico();

                    Console.ReadKey();
                    program.Menu();
                    break;

                case 2:
                    cozinha.ListarEletrodomestico();

                    Console.ReadKey();
                    program.Menu();
                    break;

                case 3:
                    quarto.ListarEletrodomestico();

                    Console.ReadKey();
                    program.Menu();
                    break;

                case 4:
                    banheiro.ListarEletrodomestico();

                    Console.ReadKey();
                    program.Menu();
                    break;

                case 5:
                    sala.ListarEletrodomestico();
                    cozinha.ListarEletrodomestico();
                    quarto.ListarEletrodomestico();
                    banheiro.ListarEletrodomestico();

                    Console.ReadKey();
                    program.Menu();
                    break;

                case 6:
                    program.Menu();
                    Console.ReadKey();
                    break;


            }

        }



        public static void CriaListaEDPadrões() //CRIA LISTA DE ELETRODOMESTICOS PADROES 
        {
            //TODOS OS VALORES DESCRITOS SÃO PARA EFEITO DE BASE PARA AS DICAS APENAS, ESTIPULADOS EM CIMA DE PESQUISAS,
            //POIS OS MESMO VARIAM DE ACORDO COM A TARIFA DE CADA ESTADO E SEU TEMPO DE CONSUMO
            
            Eletrodomésticos televisão = new Eletrodomésticos("televisão");              // ~100kwh e R$5,00 no mês           
            Eletrodomésticos computador = new Eletrodomésticos("computador");            // ~80kwh e 3,00 no mês
            Eletrodomésticos dvd = new Eletrodomésticos("dvd");                          // ~20kwh e R$1,00
            Eletrodomésticos lampadas = new Eletrodomésticos("lampadas");                // ~50kwh e R$2,00 no mês
            Eletrodomésticos geladeira = new Eletrodomésticos("geladeira");              // ~250kwh e R$12,00 no mês
            Eletrodomésticos ventilador = new Eletrodomésticos("ventilador");            // ~120kwh e R$6,00 no mês
            Eletrodomésticos arcondicionado = new Eletrodomésticos("arcondicionado");    // ~150kwh e R$7,50 no mês
            Eletrodomésticos maquinadelavar = new Eletrodomésticos ("maquina de lavar"); // ~50kwh e R$2,00 no mês
            Eletrodomésticos chuveiro = new Eletrodomésticos("chuveiro");                // ~120kwh e R$6,00 no mês

            sala_p.InserirEletrodomesticoPadrão(televisão);
            sala_p.InserirEletrodomesticoPadrão(computador);
            sala_p.InserirEletrodomesticoPadrão(arcondicionado);
            sala_p.InserirEletrodomesticoPadrão(dvd);
            sala_p.InserirEletrodomesticoPadrão(lampadas);
            sala_p.InserirEletrodomesticoPadrão(ventilador);

            quarto_p.InserirEletrodomesticoPadrão(televisão);
            quarto_p.InserirEletrodomesticoPadrão(computador);
            quarto_p.InserirEletrodomesticoPadrão(dvd);
            quarto_p.InserirEletrodomesticoPadrão(arcondicionado);
            quarto_p.InserirEletrodomesticoPadrão(lampadas);
            quarto_p.InserirEletrodomesticoPadrão(ventilador);

            banheiro_p.InserirEletrodomesticoPadrão(chuveiro);
            banheiro_p.InserirEletrodomesticoPadrão(lampadas);

            cozinha_p.InserirEletrodomesticoPadrão(geladeira);
            cozinha_p.InserirEletrodomesticoPadrão(maquinadelavar);
            cozinha_p.InserirEletrodomesticoPadrão(lampadas);

        }
        

    }
}
