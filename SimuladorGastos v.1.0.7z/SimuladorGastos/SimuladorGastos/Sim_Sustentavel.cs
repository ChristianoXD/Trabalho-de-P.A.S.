﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimuladorGastos
{
    class Sim_Sustentavel
    {

        public void SimularEconomia()
        {



        }


        public void SimularEconomiaComodo()
        {



        }


        public void SimularQtdEletrodomesticos()
        {




        }


        


    }
}
